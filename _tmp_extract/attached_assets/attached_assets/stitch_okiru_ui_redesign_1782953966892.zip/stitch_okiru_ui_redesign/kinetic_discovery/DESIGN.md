---
name: Kinetic Discovery
colors:
  surface: '#180f23'
  surface-dim: '#180f23'
  surface-bright: '#40354b'
  surface-container-lowest: '#130a1e'
  surface-container-low: '#21172c'
  surface-container: '#251b30'
  surface-container-high: '#30263b'
  surface-container-highest: '#3b3046'
  on-surface: '#eddcf9'
  on-surface-variant: '#bdc9cb'
  inverse-surface: '#eddcf9'
  inverse-on-surface: '#372c42'
  outline: '#879395'
  outline-variant: '#3d494b'
  surface-tint: '#6ad5e7'
  primary: '#e0faff'
  on-primary: '#00363d'
  primary-container: '#7ee8fa'
  on-primary-container: '#006875'
  inverse-primary: '#006875'
  secondary: '#d3bbff'
  on-secondary: '#40008d'
  secondary-container: '#5823ab'
  on-secondary-container: '#c5a6ff'
  tertiary: '#fff3f0'
  on-tertiary: '#611200'
  tertiary-container: '#ffcec2'
  on-tertiary-container: '#b42900'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9bf0ff'
  primary-fixed-dim: '#6ad5e7'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#ebddff'
  secondary-fixed-dim: '#d3bbff'
  on-secondary-fixed: '#260059'
  on-secondary-fixed-variant: '#5823ab'
  tertiary-fixed: '#ffdad2'
  tertiary-fixed-dim: '#ffb4a2'
  on-tertiary-fixed: '#3c0700'
  on-tertiary-fixed-variant: '#8a1d00'
  background: '#180f23'
  on-background: '#eddcf9'
  surface-variant: '#3b3046'
  surface-card: '#120B1E'
  surface-elevated: '#1C142B'
  text-primary: '#FFFFFF'
  text-secondary: '#A19BA8'
  vibrant-teal: '#7EE8FA'
  vibrant-purple: '#A87AFF'
  vibrant-orange: '#FF5C33'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 56px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-md:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style

The design system is built for a high-tech, AI-driven tool advisor. It captures the spirit of discovery—guiding users through a vast ecosystem of intelligence with clarity and speed. The brand personality is **visionary yet grounded**, balancing the complex nature of AI with an accessible, high-performance interface.

The aesthetic follows a **Corporate Modern** style with **Glassmorphic** accents. It utilizes a deep, immersive dark mode to minimize eye strain and allow vibrant, interlaced gradients to pop. The interface relies on crisp borders, high-contrast typography, and purposeful motion to evoke a sense of "intelligence in action."

- **Professional:** Precise alignment and systematic spacing.
- **High-Tech:** Subtle neon accents and translucent material layers.
- **Accessible:** Clear information hierarchy and generous touch targets.

## Colors

The palette is optimized for a **Dark Mode** primary experience. The foundation is a deep "Obsidian Navy" (#060110), providing a canvas that makes the primary brand colors appear luminous. 

- **Primary (Teal):** Used for primary actions, focus states, and key navigational highlights.
- **Secondary (Purple):** Reserved for discovery-based elements, AI insights, and category tags.
- **Tertiary (Orange):** An energetic accent for alerts, new features, or high-priority calls to action.
- **Neutrals:** A range of deep purples and charcoals are used to define surface hierarchy without relying on harsh blacks.

Gradients should be used sparingly, primarily as subtle backgrounds for cards or as "glow" effects behind high-level AI-generated content.

## Typography

This design system uses a dual-sans-serif approach to maximize both impact and legibility.

- **Hanken Grotesk** is chosen for headlines and display text. Its sharp, contemporary geometry feels engineered and high-tech.
- **Inter** handles all body copy and functional UI labels. It is highly legible at small sizes on screens and maintains a neutral, professional tone.

**Style Rules:**
- Use **all-caps for small labels** (label-lg, label-sm) with increased letter spacing to create a technical, "HUD" feel.
- **Tighten tracking** on large display titles to give them a modern, punchy editorial look.
- Body copy should always use **High-Contrast White** or **Secondary Grey** against the dark background to ensure accessibility.

## Layout & Spacing

The layout utilizes a **Fixed Grid** model for desktop and a **Fluid** model for mobile.

- **Desktop:** 12-column grid with a 1280px max-width. Generous margins (64px+) are used to isolate content sections, emphasizing the "advisor" nature of the tool by not overcrowding the user.
- **Mobile:** 4-column grid with 16px margins.
- **Rhythm:** An 8px linear scale (8, 16, 24, 32, 48, 64) governs all padding, margins, and component heights to ensure visual consistency.

**Discovery Layouts:**
Tool discovery should utilize a **Masonry or Multi-column Card Grid** to allow for varied content heights (e.g., descriptions of varying lengths) while maintaining a clean, systematic feel.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Glassmorphism**, rather than traditional heavy shadows.

- **Level 0 (Background):** Obsidian Navy (#060110).
- **Level 1 (Cards/Surface):** A slightly lighter navy (#120B1E) with a subtle 1px border (#FFFFFF, 10% opacity).
- **Level 2 (Hover/Floating):** Use a backdrop-blur (12px - 20px) and a semi-transparent fill. Add a "rim light" effect using a very thin, slightly brighter border to make the element feel as if it is illuminated from within.
- **AI Accents:** Use a soft "glow" (diffused shadow with 0px offset and 20px blur) using the brand's teal or purple colors to denote AI-recommended content or active states.

## Shapes

The shape language is **Rounded**, strike a balance between the precision of AI and the approachability of a tool advisor.

- **Standard Elements (Buttons, Inputs):** 0.5rem (8px) radius.
- **Large Elements (Cards, Modals):** 1rem (16px) radius for a softer, more modern containers.
- **Status Pills:** Fully rounded (pill-shaped) to distinguish them from functional buttons.
- **Icons:** Use linear icons with a 1.5pt or 2pt stroke and slightly rounded terminals to match the typography.

## Components

### Buttons
- **Primary:** Solid teal background with navy text. High-impact, used for the main tool-launching action.
- **Secondary:** Ghost style with a teal border and white text.
- **Tertiary:** Transparent background with purple text, used for less critical discovery actions.

### Tool Cards
Cards are the primary vehicle for discovery. They should feature:
- A 1px subtle border.
- A prominent category chip (pill-shape) in the top right.
- High-contrast headlines using Hanken Grotesk.
- Subtle transition on hover: card rises slightly and the border color shifts to the brand teal.

### Input Fields
Dark-filled inputs with 10% white opacity. On focus, the border should animate to a teal-to-purple gradient to reflect the "interlaced" brand logo.

### Chips & Tags
Used for tool categories (e.g., #productivity, #design). Small, pill-shaped containers with low-opacity backgrounds (15%) of the category's assigned color (Teal, Purple, or Orange) and high-saturation text.

### Progress & Loading
Use "Skeleton" loaders with a shimmering gradient that moves from left to right, utilizing the deep navy shades. AI "thinking" states should use the interlaced ring logo as a spinning or pulsing animation.