---
name: Vivid Intelligence
colors:
  surface: '#180f23'
  surface-dim: '#180f23'
  surface-bright: '#40354b'
  surface-container-lowest: '#130a1e'
  surface-container-low: '#21172c'
  surface-container: '#251b30'
  surface-container-high: '#30263b'
  surface-container-highest: '#3b3046'
  on-surface: '#eddcf9'
  on-surface-variant: '#bdc9cb'
  inverse-surface: '#eddcf9'
  inverse-on-surface: '#372c42'
  outline: '#879395'
  outline-variant: '#3d494b'
  surface-tint: '#6ad5e7'
  primary: '#e0faff'
  on-primary: '#00363d'
  primary-container: '#7ee8fa'
  on-primary-container: '#006875'
  inverse-primary: '#006875'
  secondary: '#d3bbff'
  on-secondary: '#40008d'
  secondary-container: '#5823ab'
  on-secondary-container: '#c5a6ff'
  tertiary: '#fff2ee'
  on-tertiary: '#561f00'
  tertiary-container: '#ffceb8'
  on-tertiary-container: '#a04000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9bf0ff'
  primary-fixed-dim: '#6ad5e7'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#ebddff'
  secondary-fixed-dim: '#d3bbff'
  on-secondary-fixed: '#260059'
  on-secondary-fixed-variant: '#5823ab'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb693'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7a3000'
  background: '#180f23'
  on-background: '#eddcf9'
  surface-variant: '#3b3046'
  vivid-teal: '#7EE8FA'
  deep-purple: '#A87AFF'
  bright-orange: '#FF6B00'
  electric-indigo: '#6366F1'
  surface-charcoal: '#12121A'
  surface-glass: rgba(255, 255, 255, 0.05)
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter-desktop: 24px
  margin-desktop: 80px
  gutter-mobile: 16px
  margin-mobile: 20px
  tap-target-min: 48px
---

## Brand & Style

This design system embodies a **Modern High-Energy** aesthetic, blending the precision of corporate SaaS with the vibrant dynamism of next-generation AI. It is designed to position the product as a high-velocity advisor that is both technically superior and hyper-accessible.

The visual narrative is driven by **Corporate Modernism** infused with **Glassmorphism**. It utilizes a sophisticated "Midnight" backdrop to allow vibrant brand gradients—derived from the logo's teal, purple, and orange—to pop with maximum luminosity. The experience should feel electric, intelligent, and authoritative. 

Key principles:
- **High-Velocity Navigation:** Optimized for "thumb-friendly" mobile interaction with bottom-anchored controls.
- **Card-Centric Discovery:** Information is encapsulated in clean, translucent modules to reduce cognitive load during tool discovery.
- **Luminous Interaction:** Use of "glow" effects and vibrant accents to highlight featured content and AI-generated suggestions.

## Colors

The palette is anchored by a deep **Midnight Neutral (#060110)**, providing a high-contrast stage for the brand's signature "Vivid Gradient."

- **Primary (Vivid Teal):** Used for primary actions, technical indicators, and success states. It represents clarity and the "AI spark."
- **Secondary (Deep Purple):** Used for navigation highlights, "New" badges, and interactive step indicators.
- **Tertiary (Bright Orange):** Reserved for "Featured" highlights, booster buttons, and high-energy alerts.
- **Neutral/Surface:** The system uses **Surface Charcoal (#12121A)** for card containers and **Surface Glass** for overlays to maintain depth without sacrificing legibility.

Gradients should primarily flow from **Deep Purple** to **Vivid Teal** for standard UI, and include **Bright Orange** only for high-priority discovery elements.

## Typography

This design system utilizes **Inter** across all roles to ensure maximum legibility and a systematic, tech-forward feel. 

- **Display & Headlines:** Use heavy weights (700-800) with slight negative letter-spacing to create a "dense" and authoritative impact, especially in hero sections.
- **Body Text:** Standard weight (400) with generous line-height to ensure tool descriptions are readable even in dense card layouts.
- **Labels:** Used for metadata (Pricing, Categories, Tags). These should often be uppercase when using the `label-sm` tier to differentiate from body copy.
- **Mobile Adjustments:** Headlines scale down significantly to ensure "above-the-fold" content remains visible on smaller screens without excessive scrolling.

## Layout & Spacing

The layout follows a **Fluid Grid** model with strict adherence to a 4px baseline rhythm.

- **Desktop (12-column):** Tool discovery uses a card-based grid with 24px gutters. Featured content can span 8 or 12 columns, while standard tool cards span 3 or 4 columns.
- **Mobile (4-column):** Layout shifts to a single-column stack for tool cards to maximize horizontal space for descriptions. 
- **Bottom-Oriented Mobile Navigation:** Primary interaction points (Search, Filter, Prompt Builder toggle) must be placed within the bottom 33% of the screen.
- **Touch Targets:** All interactive elements on mobile must maintain a minimum height of 48px to ensure ease of use for all users.

## Elevation & Depth

Hierarchy is established through a combination of **Tonal Layering** and **Glassmorphism**.

1.  **Level 0 (Base):** Midnight Neutral (#060110).
2.  **Level 1 (Cards/Content):** Surface Charcoal (#12121A) with a subtle 1px border (`rgba(255,255,255,0.1)`).
3.  **Level 2 (Active/Hover):** Glassmorphic fill with a `backdrop-filter: blur(12px)`.
4.  **Shadows:** Shadows are rarely used as "black" shapes; instead, "Glows" are used. Interactive elements use a soft, colored outer glow (diffused Teal or Purple) to indicate focus rather than traditional drop shadows.

## Shapes

The design system uses a **Rounded** shape language to balance the technical "Midnight" theme with a friendly, modern approachable feel.

- **Cards & Containers:** Use `rounded-lg` (16px) to create a soft, modern frame.
- **Buttons & Tags:** Use `pill-shaped` (full radius) for category tags and navigation buttons to make them feel distinct from the structural cards.
- **Input Fields:** Follow the `rounded-md` (8px) standard for a precise, "input-ready" appearance.

## Components

### Interactive 'Booster' Buttons
Specifically for the prompt builder, these buttons use a **Vibrant Gradient** background (Deep Purple to Bright Orange) with white text. On hover, they should expand slightly (1.05x scale) and emit a soft orange glow.

### Tool Category Cards
Vertical cards with an icon at the top center, a title in `headline-md`, and a count of available tools. The background uses the **Surface Glass** effect, allowing the background colors to subtly bleed through.

### Featured Tool Highlights
These cards use a 2px **Vivid Teal** border and a small "★ Featured" pill in the top right corner. The background should have a very subtle teal-to-transparent gradient at 5% opacity.

### Mobile Navigation Bar
A fixed bottom bar containing 4-5 primary icons. The active state is indicated by a **Vivid Teal** dot below the icon and a color shift of the icon itself.

### Input Fields & Selectors
Dark backgrounds (#060110) with a 1px border that shifts to **Vivid Teal** on focus. The cursor/caret should always be the primary brand teal.

### Lists & Discovery Tiles
Standard tool tiles include:
- Tool Logo (Left)
- Title & Short Description (Center)
- Pricing/Category Pills (Bottom Left)
- 'Add to Builder' CTA (Bottom Right)